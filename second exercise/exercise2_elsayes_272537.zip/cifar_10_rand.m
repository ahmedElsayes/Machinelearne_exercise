
% xx = cifar_10_rand(data(1,:));
function rnd_test = cifar_10_rand(~)
    rnd_test = randi([0 9],10000,1)
end